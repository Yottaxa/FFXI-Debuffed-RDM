Yottaxa - Debuffed Edited for RDM:
This is usuing addon version = '1.0.0.4'
Backup your existing debuffed folder.
Rename debuffed.lua to debuffed.old
Paste in the new debuffed files and sounds folder. 
You have to edit the lua to make this work for your setup:
Using notepad++ (or some other text editor), start at ~line 97 and read the comments.
Edit the various paramiters as indicated.
The array at ~ line 143-175 is the big part, where you have to know your sets for each spell.
Sounds assume a C:/windower/addons/debuffed path. IF thats not correct you have to edit lines 413-431. 
If you do not want the sounds, set line 97 to false.