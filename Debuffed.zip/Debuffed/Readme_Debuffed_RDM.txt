Yottaxa - Debuffed Edited for RDM:
This is usuing addon version = '1.0.0.4'
Backup your existing debuffed folder.
Rename debuffed.lua to debuffed.old
Paste in the new debuffed files and sounds folder. 
You have to edit the lua to make this work for your setup:
Using notepad++ (or some other text editor), start at ~line 97 and read the comments.
If you do not want the sounds, set line 97 to false.
Edit the various paramiters as indicated.

The array at ~ line 143-175 is the big part, where you have to know your sets for each spell.
--- Column #1 DURATION:
--- DURATION GEAR does **NOT*** include JSE neck. JSE neck is separate term you input above.
--- Duration gear is the sum of snotra, kishar, belt, and regal cuffs. 
--- Add the total % (example 25%) to 1 as a decimal fraction so:
--- for example I have snotra, kisha and belt, which is 25% so the number is 1.25
--- SOME sets may not have all duration gear, so change each set accordingly.

--- Column #2
---	This is simply based on how many pieces of empy+2/3 you use in your base sets outside of 
---	Composure + Sabo separately.
--- 2Pieces: +10% 3Pieces: +20% 4Pieces: +35% 5Pieces: +50% =2: 1.10 3: = 1.20 4: = 1.35 5: = 1.50

--- Column #3: COMPOSURE WITH SABO is a RARE CASE of TWO or more EMPY pieces of gear
--- It accounts for the fact that Empy Hands get SWAPPED into all sets under sabo.
---	or more with empy+2/3 a thing now.
---	The value is added to 1, so 1.10 for sets that have body
--- 2Pieces: +10% 3Pieces: +20% 4Pieces: +35% 5Pieces: +50% =2: 1.10 3: = 1.20 4: = 1.35 5: = 1.50

--- Column #4 - Relic Head. Assumes it is present in all sets. If not, edit column 3 to reflect.
--- If not, set the third comlumn to 0.  
--- Only a factor if you have merits into Enf Duration
--- Search and Replace is your friend if changing whole columns of identical gear.


Sounds assume a C:/windower/addons/debuffed path. IF thats not correct you have to edit lines 418-435. 

